<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

echo '<div style="text-align: center;padding-top:30px">这里调用的文章列表数据</div>';
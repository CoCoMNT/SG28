<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

echo '<div style="text-align: center;padding-top:30px">这里是调用的最热门的文章列表</div>';
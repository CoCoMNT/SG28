<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

echo '<div style="text-align: center;padding-top:30px">这里是调用用户中心入口的地方，位于模板文件header.html里面</div>';
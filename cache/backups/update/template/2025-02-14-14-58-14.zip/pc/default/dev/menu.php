<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

return [
    '首页' => 'index.php',
    '单网页' => 'index.php?s=tpl&m=page',
    '栏目列表页' => 'index.php?s=tpl&m=category',
    '内容详情页' => 'index.php?s=tpl&m=show',
    '搜索列表页' => 'index.php?s=tpl&m=search',
];